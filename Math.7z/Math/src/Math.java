import java.util.Arrays;
import java.util.Scanner;


public class Math {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        String str;
        String[] strarray;
        System.out.println("Please, input array if integer counts : ");
        str = in.nextLine();
        strarray = str.split(" ");
        int[] arrayint = new int[strarray.length];
        for(int i = 0; i< strarray.length; i++)
        {
            arrayint[i] = Integer.parseInt(strarray[i]);
        }
        task1(arrayint);
        task2(arrayint);
        task3(arrayint);
        bubbleSort(arrayint);
    }
    public static void task1(int[] args)
    {
        int[] even;
        even =  new int[0];//четные
        int[] odd;
        odd =  new int[0];//нечетные
        for(int i = 0; i< args.length;i++)
        {
           if(args[i]%2 == 0){
                even = addElement(even, args[i]);
            }
            else{
                odd = addElement(odd, args[i]);
            }
        }
        System.out.println("even " + Arrays.toString(even));
        System.out.println("odd " + Arrays.toString(odd));

    }
    static int[] addElement(int[] a, int e){
        //добавление элемента в массив
        a  = Arrays.copyOf(a, a.length + 1);
        a[a.length - 1] = e;
        return a;
    }
    public static void task2(int[] args)
    {
        //int[] arraysort = new int[args.length];
        Arrays.sort(args);
        System.out.println("Max item = " + args[args.length-1]);
        System.out.println("Min item = " + args[0]);
    }
    public static void task3(int[] args)
    {
        int[] three_or_nine;
        three_or_nine =  new int[0];//числа, которые делятся на 3 или на 9
        int[] five_and_seven;
        five_and_seven =  new int[0];//числа, которые делятся на 5 и 7
        for(int i = 0; i< args.length;i++)
        {
            if(args[i]%3 == 0 || args[i]%9 == 0 ){
                three_or_nine = addElement(three_or_nine, args[i]);
            }
            if(args[i]%5 == 0 && args[i]%7 == 0 ){
                five_and_seven = addElement(five_and_seven, args[i]);
            }
        }
        System.out.println("Division 3 or 9 " + Arrays.toString(three_or_nine));
        System.out.println("Division 5 and 7 " + Arrays.toString(five_and_seven));
    }
    public static void bubbleSort(int[] arr){

            for(int i = arr.length-1 ; i > 0 ; i--){
                for(int j = 0 ; j < i ; j++){
                    if( java.lang.Math.abs(arr[j]) < java.lang.Math.abs(arr[j+1]) ){
                        int tmp = arr[j];
                        arr[j] = arr[j+1];
                        arr[j+1] = tmp;
                    }
                }
            }
        System.out.println("bubbleSortABS " + Arrays.toString(arr));
    }


}
