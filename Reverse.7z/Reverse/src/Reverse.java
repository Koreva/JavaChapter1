import java.util.Scanner;
import java.util.Random;

public class Reverse {
    public static void main(String[] args) {
        task1();
        for (int i = args.length; i>0; i--)
        {
            System.out.println("Argum -> " + args[i-1]);

        }
        System.out.println("Task 3 : ");
        Scanner in = new Scanner(System.in);
        System.out.print("Input a number: ");
        int num = in.nextInt();
        task3(num);
        task4();
        task5();
        task6();

    }
    public static void task1()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Input your name: ");
        System.out.println("Hello,  " + in.nextLine());
    }

    public static void task3(int value){
        //вывести заданное количество случайных чисел с переходом и без перехода
        int[] arraycount = new int[value]; //создаем массив длина = значение, введенное пользователем
        for (int i = 0; i<value; i++)
        {
            Random ran = new Random();//наполним массив случайными числами
            int count = ran.nextInt(100);
            arraycount[i] = count;
            // System.out.println(count);
        }
        System.out.println("Every item in New string : ");
        for (int i = 0; i<arraycount.length; i++)
        {
            System.out.println(arraycount[i]);//выводим с переходом на новые строчки
        }
        System.out.println("One string : ");
        for (int i = 0; i<arraycount.length; i++)
        {
            System.out.print(arraycount[i]);//выводим без перехода на новые строчки
        }
        System.out.println(" ");
    }
    public static  void task4(){
        //вывести пароль из командной строки с сравнить его со строкой
        String truepass = "qwerty1"; // образец
        String pass;
        System.out.println("Task 4 : ");
        Scanner inpass = new Scanner(System.in);
        System.out.println("Input your password: ");
        pass = inpass.nextLine();
        if (truepass.equals(pass))
        {
            System.out.println("Success!");
        }
        else {
            System.out.println("Failed!");
        }

    }
    public  static  void task5(){
        //вывести целые числа как аргументы командной строки, подсчитать их суммы и произведения
        Scanner in = new Scanner(System.in);
        System.out.println("Task 5 : ");
        System.out.print("Input a number1: "); // число 1
        int num1 = in.nextInt();
        System.out.print("Input a number2: ");//число 2
        int num2 = in.nextInt();
        int sum = num1+num2;
        System.out.printf("%d + %d = %d ", num1, num2, sum);
        int multiplic = num1*num2;
        System.out.printf("%d + %d = %d  ",num1, num2, multiplic);
    }
    public static void task6(){
        System.out.println("Koreva 17.04.2019"); // число 1
    }
}
